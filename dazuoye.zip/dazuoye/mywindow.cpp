#include "mywindow.h"
#include "mybutton.h"

MyWindow::MyWindow(QWidget *parent) : QMainWindow(parent)
{
    this->setFixedSize(1200,1200);
    MyButton * back_btn = new MyButton(":/button3.jpg");
    back_btn->setParent(this);
    back_btn->move(20,20);
    connect(back_btn,&MyButton::clicked,this,[=](){
        emit chooseBack();
    });
}
