#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include <QPixmap>
#include <QPaintEvent>
#include <QPushButton>
#include <QDebug>
#include "mybutton.h"
#include "mywindow.h"
#include <QTimer>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    this->setFixedSize(1200,1200);
    ui->setupUi(this);
    MyButton * btn = new MyButton(":/button.jpg");
    btn->setParent(this);
    btn->move(20,20);
    MyWindow * scene = new MyWindow;
    connect(btn,&QPushButton::clicked,this,[=](){
        btn->down();
        btn->up();
        QTimer::singleShot(200,this,[=](){
            this->close();
            scene->show();
        });
    });
    connect(scene,&MyWindow::chooseBack,this,[=](){
        btn->down();
        btn->up();
        QTimer::singleShot(200,scene,[=](){
            scene->hide();
            this->show();
        });
    });
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pixmap(":/timg.jpg");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
}
