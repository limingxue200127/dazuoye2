#ifndef MYBUTTON_H
#define MYBUTTON_H

#include <QWidget>
#include <QPushButton>
class Mybutton : public QPushButton
{
    Q_OBJECT
public:
    Mybutton(QString pix);

signals:

public slots:
};

#endif // MYBUTTON_H
