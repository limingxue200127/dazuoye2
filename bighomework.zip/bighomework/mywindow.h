#ifndef MYWINDOW_H
#define MYWINDOW_H

#include <QMainWindow>

class mywindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit mywindow(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // MYWINDOW_H