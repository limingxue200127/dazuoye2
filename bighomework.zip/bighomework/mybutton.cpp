#include "mybutton.h"
#include <QPixmap>
Mybutton::Mybutton(QString pix):QPushButton(0){
    QPixmap pixmap(pix);
    this->setFixedSize(pixmap.width(),pixmap.height());
    this->setStyleSheet("QPushButton{border:opx;}");
    this->setIcon(pipxmap);
    this->setIconSize(QSize(pixmap.width(),pixmap.height()));

}
