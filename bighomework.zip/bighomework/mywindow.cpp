#include "mywindow.h"

mywindow::mywindow(QWidget *parent) : QMainWindow(parent)
{
    this->setFixedSize(800,600);
}
